$(function(e) {
	"use strict";
	
	$('.content').richText();
	$('.content2').richText();
});